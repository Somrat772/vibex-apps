// Database Webhook target: fires on INSERT into `notifications` and `calls`.
// Sends FCM (HTTP v1) pushes: call ringing, likes, comments, follows, messages, premium.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { importPKCS8, SignJWT } from "npm:jose@5";

const sa = JSON.parse(Deno.env.get("FCM_SERVICE_ACCOUNT")!); // Firebase service account JSON
const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

const PLAN_NAMES: Record<string, string> = {
  student: "Premium Students Vibe",
  pro: "Premium VibeX Pro",
  promax: "Premium VibeX Pro Max",
};

async function accessToken(): Promise<string> {
  const key = await importPKCS8(sa.private_key, "RS256");
  const jwt = await new SignJWT({ scope: "https://www.googleapis.com/auth/firebase.messaging" })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" })
    .setIssuer(sa.client_email)
    .setSubject(sa.client_email)
    .setAudience("https://oauth2.googleapis.com/token")
    .setIssuedAt()
    .setExpirationTime("55m")
    .sign(key);
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: jwt }),
  });
  return (await r.json()).access_token;
}

async function sendFcm(userId: string, message: Record<string, unknown>) {
  const { data: row } = await admin.from("device_tokens").select("token").eq("user_id", userId).maybeSingle();
  if (!row) return;
  const res = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
    method: "POST",
    headers: { Authorization: `Bearer ${await accessToken()}`, "Content-Type": "application/json" },
    body: JSON.stringify({ message: { token: row.token, ...message } }),
  });
  if (res.status === 404 || res.status === 400) {
    const t = await res.text();
    if (t.includes("UNREGISTERED") || t.includes("INVALID_ARGUMENT")) {
      await admin.from("device_tokens").delete().eq("user_id", userId); // stale token
    }
  }
}

Deno.serve(async (req) => {
  const secret = Deno.env.get("WEBHOOK_SECRET");
  if (secret && req.headers.get("x-webhook-secret") !== secret) {
    return new Response("unauthorized", { status: 401 });
  }
  const payload = await req.json();
  if (payload.type !== "INSERT") return new Response("ignored");
  const rec = payload.record;

  // ---- Incoming call: data-only, high priority so the phone rings even when the app is closed
  if (payload.table === "calls") {
    const { data: caller } = await admin.from("profiles").select("username, full_name, avatar_url").eq("id", rec.caller_id).single();
    await sendFcm(rec.callee_id, {
      data: {
        type: "call",
        call_id: rec.id,
        kind: rec.kind,
        caller_name: caller?.full_name ?? caller?.username ?? "VibeX",
        caller_avatar: caller?.avatar_url ?? "",
      },
      android: { priority: "HIGH", ttl: "30s" },
      apns: {
        headers: { "apns-priority": "10", "apns-push-type": "background" },
        payload: { aps: { "content-available": 1 } },
      },
    });
    return new Response("ok");
  }

  // ---- Notifications: like / comment / follow / message / premium
  if (payload.table === "notifications") {
    let name = "Someone";
    if (rec.actor_id) {
      const { data: a } = await admin.from("profiles").select("username").eq("id", rec.actor_id).single();
      name = a?.username ? `@${a.username}` : name;
    }
    let title = "VibeX";
    let body = "";
    switch (rec.type) {
      case "like": body = `${name} liked your post`; break;
      case "comment": body = `${name} commented: ${rec.body ?? ""}`; break;
      case "follow": body = `${name} started following you`; break;
      case "message": title = name; body = rec.body ?? "New message"; break;
      case "premium":
        title = "🎉 Congratulations!";
        body = `You are now ${PLAN_NAMES[rec.body] ?? "Premium"}. Blue tick and premium features unlocked.`;
        break;
      default: return new Response("ignored");
    }
    await sendFcm(rec.user_id, {
      notification: { title, body },
      data: { type: rec.type, post_id: rec.post_id ?? "", actor_id: rec.actor_id ?? "" },
      android: { priority: "HIGH", notification: { channel_id: "vibex_default" } },
      apns: { headers: { "apns-priority": "10" }, payload: { aps: { sound: "default" } } },
    });
  }
  return new Response("ok");
});
