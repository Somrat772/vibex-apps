// Issues a short-lived Agora RTC token, only to members of the call.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { RtcRole, RtcTokenBuilder } from "npm:agora-token@2.0.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { channel } = await req.json();
    if (!channel) return Response.json({ error: "channel required" }, { status: 400, headers: cors });

    // RLS: this only returns the call if the caller/callee is the authenticated user
    const supa = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: req.headers.get("Authorization")! } },
    });
    const { data: call } = await supa.from("calls").select("id").eq("channel", channel).maybeSingle();
    if (!call) return Response.json({ error: "forbidden" }, { status: 403, headers: cors });

    const expire = Math.floor(Date.now() / 1000) + 3600;
    const token = RtcTokenBuilder.buildTokenWithUid(
      Deno.env.get("AGORA_APP_ID")!,
      Deno.env.get("AGORA_APP_CERTIFICATE")!,
      channel,
      0, // uid 0 = any uid may use this token
      RtcRole.PUBLISHER,
      expire,
      expire,
    );
    return Response.json({ token }, { headers: cors });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500, headers: cors });
  }
});
