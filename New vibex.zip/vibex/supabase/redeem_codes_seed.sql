-- Pre-made redeem codes. Run in Supabase SQL Editor (safe to run more than once).
-- Each code works ONCE. Send the right code for the plan the buyer paid for.

-- student (30 days)
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-STU-VMQS72', 'student', 30) on conflict (code) do nothing;
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-STU-MY9ZUM', 'student', 30) on conflict (code) do nothing;
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-STU-4XAWNY', 'student', 30) on conflict (code) do nothing;
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-STU-JU2WBL', 'student', 30) on conflict (code) do nothing;
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-STU-JQ4BJ2', 'student', 30) on conflict (code) do nothing;

-- pro (30 days)
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-PRO-EXZT2D', 'pro', 30) on conflict (code) do nothing;
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-PRO-AFL385', 'pro', 30) on conflict (code) do nothing;
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-PRO-X7QVSR', 'pro', 30) on conflict (code) do nothing;
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-PRO-MC92BR', 'pro', 30) on conflict (code) do nothing;
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-PRO-BQDYFQ', 'pro', 30) on conflict (code) do nothing;

-- promax (365 days)
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-MAX-M4X52S', 'promax', 365) on conflict (code) do nothing;
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-MAX-T9CRGF', 'promax', 365) on conflict (code) do nothing;
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-MAX-RNBJJZ', 'promax', 365) on conflict (code) do nothing;
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-MAX-FSZF6X', 'promax', 365) on conflict (code) do nothing;
insert into redeem_codes (code, plan, duration_days) values ('VIBEX-MAX-D28A3Z', 'promax', 365) on conflict (code) do nothing;

-- Test code (delete before launch): 
insert into redeem_codes (code, plan, duration_days) values ('1216', 'pro', 30) on conflict (code) do nothing;
