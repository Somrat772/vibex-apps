import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_callkit_incoming/entities/entities.dart';
import 'package:flutter_callkit_incoming/flutter_callkit_incoming.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import '../core/router.dart';
import '../core/supa.dart';

/// Native full-screen incoming call UI (ringtone + Accept / Reject).
class CallUi {
  static final Set<String> _shown = {};

  static Future<void> showIncoming(Map<String, dynamic> d) async {
    final id = '${d['call_id']}';
    if (!_shown.add(id)) return; // avoid duplicates (push + realtime)
    final video = d['kind'] == 'video';
    await FlutterCallkitIncoming.showCallkitIncoming(CallKitParams(
      id: id,
      nameCaller: '${d['caller_name'] ?? 'VibeX'}',
      appName: 'VibeX',
      avatar: d['caller_avatar'] == null ? null : '${d['caller_avatar']}',
      handle: video ? 'VibeX video call' : 'VibeX audio call',
      type: video ? 1 : 0,
      duration: 30000,
      textAccept: 'Accept',
      textDecline: 'Reject',
      extra: <String, dynamic>{'call_id': id},
      android: const AndroidParams(
        isCustomNotification: true,
        isShowLogo: false,
        ringtonePath: 'system_ringtone_default',
        backgroundColor: '#070B1A',
        actionColor: '#3DA9FF',
      ),
      ios: const IOSParams(
        handleType: 'generic',
        supportsVideo: true,
        ringtonePath: 'system_ringtone_default',
      ),
    ));
  }

  static Future<void> showIncomingById(String callId) async {
    final c = await sb
        .from('calls')
        .select('id, kind, status, caller:profiles!caller_id(username, full_name, avatar_url)')
        .eq('id', callId)
        .maybeSingle();
    if (c == null || c['status'] != 'ringing') return;
    final caller = c['caller'] as Map? ?? {};
    await showIncoming({
      'call_id': c['id'],
      'kind': c['kind'],
      'caller_name': caller['full_name'] ?? caller['username'] ?? 'VibeX',
      'caller_avatar': caller['avatar_url'],
    });
  }
}

class IncomingCallListener {
  static StreamSubscription? _ev;
  static RealtimeChannel? _ch;

  static void start() {
    stop();
    _ev = FlutterCallkitIncoming.onEvent.listen(_onEvent);

    // Foreground / app-open: Realtime. Background: FCM -> CallUi (see push_service).
    _ch = sb
        .channel('incoming-calls-$myId')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: myId),
          callback: (p) => CallUi.showIncomingById('${p.newRecord['id']}'),
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: myId),
          callback: (p) {
            final s = p.newRecord['status'];
            if (s == 'missed' || s == 'ended' || s == 'rejected') {
              FlutterCallkitIncoming.endCall('${p.newRecord['id']}');
            }
          },
        )
        .subscribe();
  }

  static void stop() {
    _ev?.cancel();
    _ev = null;
    if (_ch != null) {
      sb.removeChannel(_ch!);
      _ch = null;
    }
  }

  static Future<void> _onEvent(CallEvent? event) async {
    if (event == null) return;
    final body = Map<String, dynamic>.from(event.body as Map);
    final id = '${body['id']}';
    switch (event.event) {
      case Event.actionCallAccept:
        try {
          final c = await sb
              .from('calls')
              .select('id, channel, kind, status, caller:profiles!caller_id(username, full_name, avatar_url)')
              .eq('id', id)
              .single();
          if (c['status'] != 'ringing') {
            await FlutterCallkitIncoming.endCall(id);
            return;
          }
          await sb.from('calls').update({'status': 'accepted'}).eq('id', id);
          final caller = c['caller'] as Map? ?? {};
          appRouter.push('/call', extra: {
            'callId': id,
            'channel': c['channel'],
            'video': c['kind'] == 'video',
            'peerName': caller['full_name'] ?? caller['username'] ?? 'VibeX',
            'peerAvatar': caller['avatar_url'],
            'isCaller': false,
          });
        } catch (_) {}
        break;
      case Event.actionCallDecline:
        await sb.from('calls').update({'status': 'rejected'}).eq('id', id).eq('status', 'ringing');
        break;
      case Event.actionCallTimeout:
        await sb.from('calls').update({'status': 'missed'}).eq('id', id).eq('status', 'ringing');
        break;
      default:
        break;
    }
  }
}

/// Start an audio/video call to [peer] (a profile map with id, username, full_name, avatar_url).
Future<void> startCall(BuildContext context, Map peer, {required bool video}) async {
  try {
    final call = await sb.from('calls').insert({
      'caller_id': myId,
      'callee_id': peer['id'],
      'channel': const Uuid().v4(),
      'kind': video ? 'video' : 'audio',
    }).select().single();
    if (!context.mounted) return;
    context.push('/call', extra: {
      'callId': call['id'],
      'channel': call['channel'],
      'video': video,
      'peerName': peer['full_name'] ?? peer['username'] ?? 'User',
      'peerAvatar': peer['avatar_url'],
      'isCaller': true,
    });
  } catch (e) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not start call: $e')));
    }
  }
}
