import 'package:flutter/material.dart';

class VX {
  static const bg = Color(0xFF070B1A);
  static const card = Color(0xFF0F152B);
  static const blue = Color(0xFF3DA9FF);
  static const pink = Color(0xFFD946EF);
  static const gold = Color(0xFFFFC83D);
  static const gradient = LinearGradient(colors: [blue, pink]);
}

ThemeData vibexTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: VX.bg,
    colorScheme: const ColorScheme.dark(primary: VX.blue, secondary: VX.pink, surface: VX.card),
    appBarTheme: const AppBarTheme(backgroundColor: VX.bg, elevation: 0, centerTitle: false),
    navigationBarTheme: const NavigationBarThemeData(
        backgroundColor: VX.bg, indicatorColor: Color(0x333DA9FF)),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: VX.card,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
    ),
  );
}
