import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/supa.dart';
import '../../models/plans.dart';
import '../../widgets/common.dart';

/// Admin panel: generate redeem codes, see code usage, grant/revoke premium manually.
class AdminPage extends StatefulWidget {
  const AdminPage({super.key});
  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  String _plan = 'pro';
  int _count = 1;
  List<String> _fresh = [];
  List<Map<String, dynamic>> _codes = [];
  bool _busy = false;
  final _user = TextEditingController();
  String _grantPlan = 'pro';
  final _days = TextEditingController(text: '30');

  @override
  void initState() {
    super.initState();
    _loadCodes();
  }

  Future<void> _loadCodes() async {
    final rows = await sb
        .from('redeem_codes')
        .select('code, plan, is_used, used_at, created_at, used:profiles!used_by(username)')
        .order('created_at', ascending: false)
        .limit(60);
    if (mounted) setState(() => _codes = List<Map<String, dynamic>>.from(rows));
  }

  Future<void> _generate() async {
    setState(() => _busy = true);
    try {
      final res = await sb.rpc('generate_codes', params: {'p_plan': _plan, 'p_count': _count});
      _fresh = List<String>.from(res);
      await _loadCodes();
    } catch (e) {
      if (mounted) toast(context, '$e');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _grant() async {
    try {
      await sb.rpc('admin_set_plan', params: {
        'p_username': _user.text.trim(),
        'p_plan': _grantPlan,
        'p_days': int.tryParse(_days.text) ?? 30,
      });
      if (mounted) toast(context, _grantPlan == 'free' ? 'Premium removed' : 'Premium granted');
    } catch (e) {
      if (mounted) toast(context, '$e');
    }
  }

  Widget _planDropdown(String value, ValueChanged<String?> onChanged, {bool withFree = false}) =>
      DropdownButtonFormField<String>(
        value: value,
        items: [
          if (withFree) const DropdownMenuItem(value: 'free', child: Text('Remove premium (free)')),
          for (final p in plans) DropdownMenuItem(value: p.id, child: Text(p.name)),
        ],
        onChanged: onChanged,
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Admin panel')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Generate redeem codes', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 10),
          _planDropdown(_plan, (v) => setState(() => _plan = v!)),
          const SizedBox(height: 10),
          Row(children: [
            const Text('How many:'),
            Expanded(
              child: Slider(
                  value: _count.toDouble(), min: 1, max: 20, divisions: 19, label: '$_count', onChanged: (v) => setState(() => _count = v.round())),
            ),
            Text('$_count'),
          ]),
          SizedBox(
              width: double.infinity,
              child: GradientButton(label: _busy ? 'Generating...' : 'Generate', onTap: _busy ? null : _generate)),
          if (_fresh.isNotEmpty) ...[
            const SizedBox(height: 12),
            const Text('New codes (tap to copy):'),
            for (final c in _fresh)
              ListTile(
                dense: true,
                title: SelectableText(c, style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
                trailing: const Icon(Icons.copy, size: 18),
                onTap: () {
                  Clipboard.setData(ClipboardData(text: c));
                  toast(context, 'Copied $c');
                },
              ),
          ],
          const Divider(height: 36),
          const Text('Grant / remove premium by username', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 10),
          TextField(controller: _user, decoration: const InputDecoration(labelText: 'Username', prefixText: '@')),
          const SizedBox(height: 10),
          _planDropdown(_grantPlan, (v) => setState(() => _grantPlan = v!), withFree: true),
          const SizedBox(height: 10),
          TextField(controller: _days, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Days')),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: FilledButton(onPressed: _grant, child: const Text('Apply'))),
          const Divider(height: 36),
          Row(children: [
            const Expanded(child: Text('Recent codes', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
            IconButton(icon: const Icon(Icons.refresh), onPressed: _loadCodes),
          ]),
          for (final c in _codes)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text(c['code'],
                  style: TextStyle(decoration: c['is_used'] == true ? TextDecoration.lineThrough : null)),
              subtitle: Text(c['is_used'] == true
                  ? 'Used by @${(c['used'] as Map?)?['username'] ?? '?'}'
                  : '${planName(c['plan'])} - unused'),
              trailing: Icon(c['is_used'] == true ? Icons.check_circle : Icons.hourglass_empty,
                  color: c['is_used'] == true ? Colors.greenAccent : Colors.orangeAccent, size: 18),
            ),
        ]),
      );
}
