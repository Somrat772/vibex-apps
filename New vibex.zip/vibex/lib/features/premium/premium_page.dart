import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/config.dart';
import '../../core/supa.dart';
import '../../core/theme.dart';
import '../../models/plans.dart';
import '../../widgets/common.dart';
import 'redeem_dialog.dart';

/// Opens WhatsApp with a pre-filled message for the admin.
Future<void> applyViaWhatsApp(BuildContext context, Plan plan) async {
  try {
    final user = sb.auth.currentUser!;
    final p = await sb.from('profiles').select('username, full_name').eq('id', user.id).single();
    final msg = '''Hello VibeX Admin, I want to buy a premium subscription.

Profile name: ${p['full_name']}
Username: @${p['username']}
User ID: ${user.id}
Email / Phone: ${user.email ?? user.phone}

Subscription: ${plan.name}
Price: ${plan.price} / ${plan.period}

Please tell me the payment details and send me the redeem code after payment.''';
    final uri = Uri.parse('https://wa.me/${Config.adminWhatsApp}?text=${Uri.encodeComponent(msg)}');
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) toast(context, 'Could not open WhatsApp. Is it installed?');
  } catch (e) {
    if (context.mounted) toast(context, 'Error: $e');
  }
}

class PremiumPage extends StatefulWidget {
  const PremiumPage({super.key});
  @override
  State<PremiumPage> createState() => _PremiumPageState();
}

class _PremiumPageState extends State<PremiumPage> {
  Map<String, dynamic>? _me;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await sb.from('profiles').select('plan, premium_expires_at, badge').eq('id', myId).single();
    if (mounted) setState(() => _me = p);
  }

  @override
  Widget build(BuildContext context) {
    final premium = isPremium(_me);
    return Scaffold(
      appBar: AppBar(title: const Text('Get Premium')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (premium)
          Container(
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                gradient: VX.gradient, borderRadius: BorderRadius.circular(16)),
            child: Row(children: [
              VerifiedBadge(badge: _me!['badge'], size: 34),
              const SizedBox(width: 6),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('You are ${planName(_me!['plan'])}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text('Active until ${DateTime.parse(_me!['premium_expires_at']).toLocal().toString().substring(0, 10)}'),
                ]),
              ),
            ]),
          ),
        for (final p in plans)
          Container(
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: VX.card,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: p.id == 'promax' ? VX.gold : Colors.white12),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(p.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
                Icon(Icons.verified, color: p.id == 'promax' ? VX.gold : VX.blue),
              ]),
              const SizedBox(height: 4),
              Text('${p.price} / ${p.period}', style: const TextStyle(fontSize: 24, color: VX.blue, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              for (final perk in p.perks)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(children: [
                    const Icon(Icons.check_circle, size: 16, color: Colors.greenAccent),
                    const SizedBox(width: 8),
                    Expanded(child: Text(perk)),
                  ]),
                ),
              const SizedBox(height: 14),
              SizedBox(
                  width: double.infinity,
                  child: GradientButton(
                      label: 'Apply via WhatsApp',
                      icon: Icons.chat,
                      onTap: () => applyViaWhatsApp(context, p))),
            ]),
          ),
        const SizedBox(height: 4),
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
          icon: const Icon(Icons.card_giftcard),
          label: const Text('I have a Redeem Code'),
          onPressed: () async {
            await showRedeemDialog(context);
            _load();
          },
        ),
        const SizedBox(height: 10),
        const Text(
          'Payment is handled manually on WhatsApp. After payment the admin sends you a one-time redeem code.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white54, fontSize: 12),
        ),
      ]),
    );
  }
}
