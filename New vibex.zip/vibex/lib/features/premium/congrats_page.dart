import 'dart:math';
import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/supa.dart';
import '../../core/theme.dart';
import '../../models/plans.dart';
import '../../widgets/common.dart';

class CongratsPage extends StatefulWidget {
  final String plan, expiresAt;
  const CongratsPage({super.key, required this.plan, required this.expiresAt});
  @override
  State<CongratsPage> createState() => _CongratsPageState();
}

class _CongratsPageState extends State<CongratsPage> {
  final _confetti = ConfettiController(duration: const Duration(seconds: 4));
  Map<String, dynamic>? _me;

  @override
  void initState() {
    super.initState();
    _confetti.play();
    sb.from('profiles').select().eq('id', myId).single().then((v) {
      if (mounted) setState(() => _me = v);
    });
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final plan = plans.firstWhere((p) => p.id == widget.plan, orElse: () => plans.first);
    return Scaffold(
      body: SafeArea(
        child: Stack(alignment: Alignment.topCenter, children: [
          ConfettiWidget(
            confettiController: _confetti,
            blastDirection: pi / 2,
            emissionFrequency: .06,
            numberOfParticles: 18,
            gravity: .25,
            colors: const [VX.blue, VX.pink, VX.gold, Colors.white],
          ),
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: const BoxDecoration(shape: BoxShape.circle, gradient: VX.gradient),
                  child: Avatar(url: _me?['avatar_url'], radius: 62),
                ),
                const SizedBox(height: 16),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  Text('@${_me?['username'] ?? ''}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  VerifiedBadge(badge: _me?['badge'] ?? 'blue', size: 26),
                ]),
                const SizedBox(height: 22),
                const Text('🎉 Congratulations!', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Text('You are now ${plan.name}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18)),
                const SizedBox(height: 4),
                Text('Valid until ${DateTime.parse(widget.expiresAt).toLocal().toString().substring(0, 10)}',
                    style: const TextStyle(color: Colors.white60)),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: VX.card, borderRadius: BorderRadius.circular(16)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Your premium features', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    for (final perk in plan.perks)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: Row(children: [
                          const Icon(Icons.check_circle, size: 18, color: Colors.greenAccent),
                          const SizedBox(width: 8),
                          Expanded(child: Text(perk)),
                        ]),
                      ),
                  ]),
                ),
                const SizedBox(height: 24),
                SizedBox(
                    width: double.infinity,
                    child: GradientButton(label: 'Start using VibeX', onTap: () => context.go('/'))),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}
