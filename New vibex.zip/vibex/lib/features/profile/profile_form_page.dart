import 'dart:io';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/router.dart';
import '../../core/supa.dart';
import '../../widgets/common.dart';

/// Used twice: first-time account setup (isSetup: true) and Edit Profile.
class ProfileFormPage extends StatefulWidget {
  final bool isSetup;
  const ProfileFormPage({super.key, required this.isSetup});
  @override
  State<ProfileFormPage> createState() => _ProfileFormPageState();
}

class _ProfileFormPageState extends State<ProfileFormPage> {
  final _name = TextEditingController();
  final _username = TextEditingController();
  final _bio = TextEditingController();
  File? _avatar, _cover;
  String? _avatarUrl, _coverUrl, _error;
  bool _saving = false, _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await sb.from('profiles').select().eq('id', myId).single();
    _name.text = p['full_name'] ?? '';
    _username.text = p['username'] ?? '';
    _bio.text = p['bio'] ?? '';
    _avatarUrl = p['avatar_url'];
    _coverUrl = p['cover_url'];
    if (mounted) setState(() => _loading = false);
  }

  Future<File?> _pick({double? maxWidth}) async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: maxWidth ?? 1280, imageQuality: 85);
    return x == null ? null : File(x.path);
  }

  Future<String> _upload(File f, String bucket) async {
    final path = '$myId/${DateTime.now().millisecondsSinceEpoch}.jpg';
    await sb.storage.from(bucket).upload(path, f, fileOptions: const FileOptions(contentType: 'image/jpeg'));
    return sb.storage.from(bucket).getPublicUrl(path);
  }

  Future<void> _save() async {
    final u = _username.text.trim().toLowerCase();
    if (_name.text.trim().isEmpty) return setState(() => _error = 'Please enter your name');
    if (!RegExp(r'^[a-z0-9_.]{3,20}$').hasMatch(u)) {
      return setState(() => _error = 'Username: 3-20 characters, letters, numbers, _ or .');
    }
    if (widget.isSetup && _avatar == null && _avatarUrl == null) {
      return setState(() => _error = 'Please choose a profile picture from your gallery');
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      final data = <String, dynamic>{
        'full_name': _name.text.trim(),
        'username': u,
        'bio': _bio.text.trim(),
        if (widget.isSetup) 'setup_complete': true,
      };
      if (_avatar != null) data['avatar_url'] = await _upload(_avatar!, 'avatars');
      if (_cover != null) data['cover_url'] = await _upload(_cover!, 'covers');
      await sb.from('profiles').update(data).eq('id', myId);
      if (!mounted) return;
      if (widget.isSetup) {
        setupFinished();
        context.go('/');
      } else {
        context.pop();
      }
    } on PostgrestException catch (e) {
      setState(() => _error = e.code == '23505' ? 'That username is already taken' : e.message);
    } catch (e) {
      setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isSetup ? 'Set up your profile' : 'Edit profile'),
        automaticallyImplyLeading: !widget.isSetup,
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(20, 0, 20, 30), children: [
        GestureDetector(
          onTap: () async {
            final f = await _pick(maxWidth: 1600);
            if (f != null) setState(() => _cover = f);
          },
          child: Container(
            height: 140,
            decoration: BoxDecoration(
              color: Colors.white10,
              borderRadius: BorderRadius.circular(16),
              image: _cover != null
                  ? DecorationImage(image: FileImage(_cover!), fit: BoxFit.cover)
                  : _coverUrl != null
                      ? DecorationImage(image: NetworkImage(_coverUrl!), fit: BoxFit.cover)
                      : null,
            ),
            child: (_cover == null && _coverUrl == null)
                ? const Center(child: Text('Tap to add a cover photo', style: TextStyle(color: Colors.white54)))
                : null,
          ),
        ),
        Transform.translate(
          offset: const Offset(0, -44),
          child: Center(
            child: GestureDetector(
              onTap: () async {
                final f = await _pick(maxWidth: 1024);
                if (f != null) setState(() => _avatar = f);
              },
              child: Stack(children: [
                CircleAvatar(
                  radius: 52,
                  backgroundColor: const Color(0xFF1A2140),
                  backgroundImage: _avatar != null
                      ? FileImage(_avatar!) as ImageProvider
                      : (_avatarUrl != null ? NetworkImage(_avatarUrl!) : null),
                  child: (_avatar == null && _avatarUrl == null) ? const Icon(Icons.add_a_photo, size: 30) : null,
                ),
                const Positioned(
                    right: 0,
                    bottom: 0,
                    child: CircleAvatar(radius: 15, child: Icon(Icons.edit, size: 16))),
              ]),
            ),
          ),
        ),
        Transform.translate(
          offset: const Offset(0, -24),
          child: Column(children: [
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Full name')),
            const SizedBox(height: 12),
            TextField(
                controller: _username,
                decoration: const InputDecoration(labelText: 'Username', prefixText: '@')),
            const SizedBox(height: 12),
            TextField(
                controller: _bio,
                maxLines: 3,
                maxLength: 160,
                decoration: const InputDecoration(labelText: 'Bio')),
            if (_error != null)
              Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(_error!, style: const TextStyle(color: Colors.redAccent))),
            const SizedBox(height: 16),
            SizedBox(
                width: double.infinity,
                child: GradientButton(
                    label: _saving ? 'Saving...' : (widget.isSetup ? 'Continue' : 'Save'),
                    onTap: _saving ? null : _save)),
          ]),
        ),
      ]),
    );
  }
}
