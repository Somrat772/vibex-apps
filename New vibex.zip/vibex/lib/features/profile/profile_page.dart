import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/supa.dart';
import '../../core/theme.dart';
import '../../models/plans.dart';
import '../../services/call_service.dart';
import '../../services/chat_service.dart';
import '../../services/posts_service.dart';
import '../../services/push_service.dart';
import '../../widgets/common.dart';

class ProfilePage extends StatefulWidget {
  final String userId;
  final bool isTab;
  const ProfilePage({super.key, required this.userId, this.isTab = false});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Map<String, dynamic>? _p;
  Map<String, dynamic> _stats = {'followers': 0, 'following': 0};
  List<Map<String, dynamic>> _posts = [];
  bool _following = false, _loading = true;

  bool get _mine => widget.userId == myId;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await sb.from('profiles').select().eq('id', widget.userId).single();
      final st = await sb.from('profile_stats').select().eq('id', widget.userId).single();
      final posts = await fetchPosts(authorId: widget.userId, from: 0, to: 29);
      var f = false;
      if (!_mine) {
        f = await sb
                .from('follows')
                .select('follower_id')
                .eq('follower_id', myId)
                .eq('following_id', widget.userId)
                .maybeSingle() !=
            null;
      }
      if (!mounted) return;
      setState(() {
        _p = p;
        _stats = st;
        _posts = posts;
        _following = f;
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _toggleFollow() async {
    final next = !_following;
    setState(() {
      _following = next;
      _stats = {..._stats, 'followers': (_stats['followers'] as int) + (next ? 1 : -1)};
    });
    try {
      if (next) {
        await sb.from('follows').insert({'follower_id': myId, 'following_id': widget.userId});
      } else {
        await sb.from('follows').delete().match({'follower_id': myId, 'following_id': widget.userId});
      }
    } catch (_) {
      _load();
    }
  }

  Future<void> _logout() async {
    await PushService.onLogout();
    await sb.auth.signOut();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final p = _p;
    if (p == null) return Scaffold(appBar: AppBar(), body: const Center(child: Text('Profile not found')));
    final premium = isPremium(p);
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: !widget.isTab,
        title: Text('@${p['username'] ?? ''}'),
        actions: [
          if (_mine)
            PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'edit') context.push('/edit-profile').then((_) => _load());
                if (v == 'premium') context.push('/premium').then((_) => _load());
                if (v == 'admin') context.push('/admin');
                if (v == 'logout') _logout();
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'edit', child: Text('Edit profile')),
                const PopupMenuItem(value: 'premium', child: Text('Premium / Redeem code')),
                if (p['is_admin'] == true) const PopupMenuItem(value: 'admin', child: Text('Admin panel')),
                const PopupMenuItem(value: 'logout', child: Text('Log out')),
              ],
            ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.zero, children: [
          // cover + avatar
          SizedBox(
            height: 190,
            child: Stack(clipBehavior: Clip.none, children: [
              Positioned.fill(
                child: p['cover_url'] != null
                    ? CachedNetworkImage(imageUrl: p['cover_url'], fit: BoxFit.cover)
                    : Container(decoration: const BoxDecoration(gradient: VX.gradient)),
              ),
              Positioned(
                left: 16,
                bottom: -40,
                child: CircleAvatar(
                    radius: 48, backgroundColor: VX.bg, child: Avatar(url: p['avatar_url'], radius: 44)),
              ),
            ]),
          ),
          const SizedBox(height: 48),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              NameRow(p,
                  useFullName: true,
                  badgeSize: 22,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              Text('@${p['username']}', style: const TextStyle(color: Colors.white54)),
              if (_mine && premium)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(
                      '${planName(p['plan'])} - until ${DateTime.parse(p['premium_expires_at']).toLocal().toString().substring(0, 10)}',
                      style: const TextStyle(color: VX.gold, fontSize: 12)),
                ),
              if ((p['bio'] ?? '').toString().isNotEmpty)
                Padding(padding: const EdgeInsets.only(top: 8), child: Text(p['bio'])),
              const SizedBox(height: 14),
              Row(children: [
                _stat('${_posts.length}', 'Posts'),
                _stat('${_stats['followers']}', 'Followers'),
                _stat('${_stats['following']}', 'Following'),
              ]),
              const SizedBox(height: 14),
              if (_mine)
                Row(children: [
                  Expanded(
                      child: OutlinedButton(
                          onPressed: () => context.push('/edit-profile').then((_) => _load()),
                          child: const Text('Edit profile'))),
                  const SizedBox(width: 10),
                  Expanded(
                      child: GradientButton(
                          label: premium ? 'Premium' : 'Get Premium',
                          icon: Icons.workspace_premium,
                          onTap: () => context.push('/premium').then((_) => _load()))),
                ])
              else
                Row(children: [
                  Expanded(
                      child: _following
                          ? OutlinedButton(onPressed: _toggleFollow, child: const Text('Following'))
                          : FilledButton(onPressed: _toggleFollow, child: const Text('Follow'))),
                  const SizedBox(width: 8),
                  Expanded(
                      child: OutlinedButton(
                          onPressed: () async {
                            final id = await ChatService.openChat(widget.userId);
                            if (context.mounted) context.push('/chat/$id', extra: p);
                          },
                          child: const Text('Message'))),
                  IconButton(icon: const Icon(Icons.call), onPressed: () => startCall(context, p, video: false)),
                  IconButton(icon: const Icon(Icons.videocam), onPressed: () => startCall(context, p, video: true)),
                ]),
              const SizedBox(height: 16),
            ]),
          ),
          const Divider(height: 1),
          if (_posts.isEmpty)
            const Padding(padding: EdgeInsets.all(40), child: Center(child: Text('No posts yet')))
          else
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.all(2),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, mainAxisSpacing: 2, crossAxisSpacing: 2),
              itemCount: _posts.length,
              itemBuilder: (_, i) {
                final x = _posts[i];
                return GestureDetector(
                  onTap: () => context.push('/post/${x['id']}'),
                  child: Container(
                    color: VX.card,
                    child: x['type'] == 'image'
                        ? CachedNetworkImage(imageUrl: x['media_url'], fit: BoxFit.cover)
                        : x['type'] == 'reel'
                            ? const Center(child: Icon(Icons.play_circle_outline, size: 36))
                            : Padding(
                                padding: const EdgeInsets.all(8),
                                child: Text(x['body'] ?? '', maxLines: 5, overflow: TextOverflow.ellipsis)),
                  ),
                );
              },
            ),
        ]),
      ),
    );
  }

  Widget _stat(String n, String label) => Expanded(
        child: Column(children: [
          Text(n, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text(label, style: const TextStyle(color: Colors.white54, fontSize: 12)),
        ]),
      );
}
