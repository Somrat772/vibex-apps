import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../core/supa.dart';
import '../../core/theme.dart';
import '../../models/plans.dart';
import '../../widgets/common.dart';

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});
  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final rows = await sb
        .from('notifications')
        .select('*, actor:profiles!actor_id(id, username, avatar_url, badge)')
        .eq('user_id', myId)
        .neq('type', 'message')
        .order('created_at', ascending: false)
        .limit(80);
    if (mounted) {
      setState(() {
        _items = List<Map<String, dynamic>>.from(rows);
        _loading = false;
      });
    }
    // mark all as read
    await sb.from('notifications').update({'is_read': true}).eq('user_id', myId).eq('is_read', false);
  }

  String _text(Map<String, dynamic> n) {
    switch (n['type']) {
      case 'like':
        return 'liked your post';
      case 'comment':
        return 'commented: ${n['body'] ?? ''}';
      case 'follow':
        return 'started following you';
      case 'premium':
        return 'Congratulations! You are now ${planName('${n['body']}')}';
      default:
        return '';
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Notifications')),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _items.isEmpty
                ? const Center(child: Text('Nothing here yet'))
                : RefreshIndicator(
                    onRefresh: _load,
                    child: ListView.builder(
                      itemCount: _items.length,
                      itemBuilder: (_, i) {
                        final n = _items[i];
                        final a = n['actor'] as Map?;
                        final isPremiumN = n['type'] == 'premium';
                        return ListTile(
                          tileColor: n['is_read'] == false ? const Color(0x1A3DA9FF) : null,
                          leading: isPremiumN
                              ? const CircleAvatar(backgroundColor: VX.gold, child: Icon(Icons.workspace_premium, color: Colors.black))
                              : Avatar(url: a?['avatar_url']),
                          title: isPremiumN
                              ? Text(_text(n))
                              : Row(children: [
                                  Flexible(child: NameRow(a)),
                                  const SizedBox(width: 6),
                                  Flexible(flex: 3, child: Text(_text(n), overflow: TextOverflow.ellipsis, maxLines: 2)),
                                ]),
                          subtitle: Text(timeago.format(DateTime.parse(n['created_at']).toLocal()),
                              style: const TextStyle(fontSize: 11)),
                          onTap: () {
                            if (n['post_id'] != null) context.push('/post/${n['post_id']}');
                            if (n['type'] == 'follow' && a != null) context.push('/profile/${a['id']}');
                          },
                        );
                      },
                    ),
                  ),
      );
}
