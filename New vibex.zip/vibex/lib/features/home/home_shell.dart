import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/supa.dart';
import '../../core/theme.dart';
import '../chat/chat_list_page.dart';
import '../feed/feed_page.dart';
import '../feed/reels_page.dart';
import '../profile/profile_page.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;
  late final Stream<List<Map<String, dynamic>>> _notifs =
      sb.from('notifications').stream(primaryKey: ['id']).eq('user_id', myId);

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const FeedPage(),
      ReelsPage(active: _i == 1),
      const SizedBox.shrink(),
      const ChatListPage(),
      ProfilePage(userId: myId, isTab: true),
    ];
    return Scaffold(
      appBar: (_i == 0 || _i == 3)
          ? AppBar(
              title: _i == 0
                  ? ShaderMask(
                      shaderCallback: (r) => VX.gradient.createShader(r),
                      child: const Text('VibeX',
                          style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: Colors.white)))
                  : const Text('Messages', style: TextStyle(fontWeight: FontWeight.bold)),
              actions: [
                IconButton(icon: const Icon(Icons.search), onPressed: () => context.push('/search')),
                if (_i == 0) ...[
                  StreamBuilder<List<Map<String, dynamic>>>(
                    stream: _notifs,
                    builder: (c, s) {
                      final n = (s.data ?? []).where((r) => r['is_read'] == false && r['type'] != 'message').length;
                      return IconButton(
                        icon: Badge(
                            isLabelVisible: n > 0,
                            label: Text('$n'),
                            child: const Icon(Icons.notifications_none)),
                        onPressed: () => context.push('/notifications'),
                      );
                    },
                  ),
                  IconButton(
                      icon: const Icon(Icons.workspace_premium, color: VX.gold),
                      onPressed: () => context.push('/premium')),
                ],
              ],
            )
          : null,
      body: IndexedStack(index: _i, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (i) {
          if (i == 2) {
            context.push('/create');
          } else {
            setState(() => _i = i);
          }
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Feed'),
          NavigationDestination(
              icon: Icon(Icons.play_circle_outline), selectedIcon: Icon(Icons.play_circle), label: 'Reels'),
          NavigationDestination(icon: Icon(Icons.add_box_outlined), label: 'Create'),
          NavigationDestination(
              icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Chats'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
