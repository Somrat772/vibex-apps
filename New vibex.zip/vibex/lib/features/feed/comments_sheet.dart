import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../core/supa.dart';
import '../../widgets/common.dart';

Future<void> showCommentsSheet(BuildContext context, String postId, {VoidCallback? onAdded}) {
  return showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: const Color(0xFF0B1022),
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (_) => _CommentsSheet(postId: postId, onAdded: onAdded),
  );
}

class _CommentsSheet extends StatefulWidget {
  final String postId;
  final VoidCallback? onAdded;
  const _CommentsSheet({required this.postId, this.onAdded});
  @override
  State<_CommentsSheet> createState() => _CommentsSheetState();
}

class _CommentsSheetState extends State<_CommentsSheet> {
  final _ctrl = TextEditingController();
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final rows = await sb
        .from('comments')
        .select('*, author:profiles!author_id(id, username, avatar_url, badge)')
        .eq('post_id', widget.postId)
        .order('created_at', ascending: true);
    if (mounted) {
      setState(() {
        _items = List<Map<String, dynamic>>.from(rows);
        _loading = false;
      });
    }
  }

  Future<void> _send() async {
    final t = _ctrl.text.trim();
    if (t.isEmpty) return;
    _ctrl.clear();
    await sb.from('comments').insert({'post_id': widget.postId, 'author_id': myId, 'body': t});
    widget.onAdded?.call();
    await _load();
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * .7,
          child: Column(children: [
            const SizedBox(height: 12),
            const Text('Comments', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const Divider(),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _items.isEmpty
                      ? const Center(child: Text('No comments yet. Be the first!'))
                      : ListView.builder(
                          itemCount: _items.length,
                          itemBuilder: (_, i) {
                            final c = _items[i];
                            final a = c['author'] as Map?;
                            return ListTile(
                              leading: GestureDetector(
                                  onTap: () {
                                    Navigator.pop(context);
                                    context.push('/profile/${a?['id']}');
                                  },
                                  child: Avatar(url: a?['avatar_url'])),
                              title: Row(children: [
                                NameRow(a),
                                const SizedBox(width: 8),
                                Text(timeago.format(DateTime.parse(c['created_at']).toLocal()),
                                    style: const TextStyle(fontSize: 11, color: Colors.white38)),
                              ]),
                              subtitle: Text(c['body']),
                              trailing: a?['id'] == myId
                                  ? IconButton(
                                      icon: const Icon(Icons.delete_outline, size: 18),
                                      onPressed: () async {
                                        await sb.from('comments').delete().eq('id', c['id']);
                                        _load();
                                      })
                                  : null,
                            );
                          },
                        ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(children: [
                Expanded(
                    child: TextField(
                        controller: _ctrl,
                        decoration: const InputDecoration(hintText: 'Add a comment...'),
                        onSubmitted: (_) => _send())),
                IconButton(icon: const Icon(Icons.send), onPressed: _send),
              ]),
            ),
          ]),
        ),
      );
}
