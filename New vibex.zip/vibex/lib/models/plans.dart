class Plan {
  final String id, name, price, period;
  final List<String> perks;
  const Plan(this.id, this.name, this.price, this.period, this.perks);
}

const plans = [
  Plan('student', 'Premium Students Vibe', '৳299', '1 month', [
    'Blue tick on profile, posts, comments & chats',
    'Unlimited posts per day',
    'Upload reels up to 5 minutes',
    'Student badge'
  ]),
  Plan('pro', 'Premium VibeX Pro', '৳499', '1 month', [
    'Blue tick everywhere',
    'Unlimited posts per day',
    'Upload reels up to 5 minutes',
    'Priority support'
  ]),
  Plan('promax', 'Premium VibeX Pro Max', '৳1999', '1 year', [
    'Golden tick everywhere',
    'Unlimited posts per day',
    'Upload reels up to 5 minutes',
    'All Pro perks for a full year',
    'Top priority support'
  ]),
];

String planName(String id) {
  for (final p in plans) {
    if (p.id == id) return p.name;
  }
  return 'Free';
}

bool isPremium(Map? p) {
  if (p == null) return false;
  final exp = p['premium_expires_at'];
  return p['plan'] != null &&
      p['plan'] != 'free' &&
      exp != null &&
      DateTime.parse(exp).isAfter(DateTime.now());
}
