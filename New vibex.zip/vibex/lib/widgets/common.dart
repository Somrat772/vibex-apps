import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../core/theme.dart';

void toast(BuildContext c, String m) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m)));
}

class Avatar extends StatelessWidget {
  final String? url;
  final double radius;
  const Avatar({super.key, this.url, this.radius = 20});
  @override
  Widget build(BuildContext context) => CircleAvatar(
        radius: radius,
        backgroundColor: Colors.white12,
        backgroundImage: url != null ? CachedNetworkImageProvider(url!) : null,
        child: url == null ? Icon(Icons.person, size: radius) : null,
      );
}

class VerifiedBadge extends StatelessWidget {
  final String? badge; // none | blue | gold
  final double size;
  const VerifiedBadge({super.key, this.badge, this.size = 16});
  @override
  Widget build(BuildContext context) {
    if (badge == null || badge == 'none') return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Icon(Icons.verified, size: size, color: badge == 'gold' ? VX.gold : VX.blue),
    );
  }
}

/// Username + verified badge. Used everywhere a user's name is shown
/// (posts, comments, chat heads, profile, search, notifications).
class NameRow extends StatelessWidget {
  final Map? p;
  final double badgeSize;
  final TextStyle? style;
  final bool useFullName;
  const NameRow(this.p, {super.key, this.badgeSize = 16, this.style, this.useFullName = false});
  @override
  Widget build(BuildContext context) {
    final name = (useFullName
            ? (p?['full_name'] ?? p?['username'])
            : (p?['username'] ?? p?['full_name'])) ??
        'user';
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Flexible(
          child: Text('$name',
              overflow: TextOverflow.ellipsis,
              style: style ?? const TextStyle(fontWeight: FontWeight.w700))),
      VerifiedBadge(badge: p?['badge'], size: badgeSize),
    ]);
  }
}

class GradientButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  const GradientButton({super.key, required this.label, this.icon, this.onTap});
  @override
  Widget build(BuildContext context) => Opacity(
        opacity: onTap == null ? .5 : 1,
        child: Material(
          color: Colors.transparent,
          child: Ink(
            decoration: BoxDecoration(gradient: VX.gradient, borderRadius: BorderRadius.circular(14)),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 18),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  if (icon != null) ...[Icon(icon, size: 20), const SizedBox(width: 8)],
                  Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                ]),
              ),
            ),
          ),
        ),
      );
}
