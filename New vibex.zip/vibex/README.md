# VibeX - QUICK START (test with only Supabase)

You do NOT need Firebase or Agora to start testing. With only Supabase configured
(`lib/core/config.dart` already has your URL + key) these work: sign up/login, profile setup, feed,
reels, chat (text/photo/voice), search, follow, premium page, WhatsApp button, redeem codes, admin panel.
Push notifications and calls switch on later when you add Firebase / Agora.

## Supabase steps (do once)
1. SQL Editor -> run `supabase/schema.sql`, then `supabase/redeem_codes_seed.sql`.
2. Authentication -> Providers -> Email: on. Turn **Confirm email OFF** while testing.
3. Sign up in the app, then make yourself admin (SQL Editor):
   `update profiles set is_admin = true where id = (select id from auth.users where email = 'YOUR_EMAIL');`

## How to get an APK without installing Flutter (GitHub)
1. Make a free GitHub repo, upload ALL files of this folder (keep `.github/` and `tools/`).
2. Repo -> Actions -> "Build Android APK" -> Run workflow.
3. When it turns green (about 10-15 min) open the run -> Artifacts -> **vibex-apk** -> download, unzip, install `app-release.apk`.
If the build fails, copy the red error text from the log and send it to Claude.

## Or run on your PC (Flutter installed)
```bash
bash tools/prepare_android.sh      # creates + patches android/
flutter pub get
flutter run
```

---

# VibeX - complete setup guide

Flutter app + Supabase backend + Firebase push + Agora calls.
Everything below is already coded: login (email / phone OTP, persistent session), account setup,
profiles with blue/gold tick, feed, reels, realtime chat (text/photo/voice), audio/video calls with
incoming-call screen, push notifications, WhatsApp premium purchase, redeem codes, admin panel.

## 1. Supabase
1. Create a project at supabase.com.
2. SQL Editor -> paste `supabase/schema.sql` -> Run.
3. Authentication -> Providers:
   - Email: enabled. (For testing turn **Confirm email** off, or users must confirm by mail first.)
   - Phone: enabled + connect an SMS provider (Twilio / MessageBird / Vonage). Phone OTP needs this.
4. Sign up once in the app, then make yourself admin (SQL Editor):
   `update profiles set is_admin = true where id = (select id from auth.users where email = 'you@example.com');`
5. Copy Project URL + anon key -> `lib/core/config.dart` (or use `--dart-define`).

## 2. Firebase (push notifications + call ringing when app is closed)
1. console.firebase.google.com -> new project -> add Android app (package `com.vibex.vibex`) and iOS app.
2. Download `google-services.json` -> `android/app/`, and `GoogleService-Info.plist` -> `ios/Runner/`.
3. iOS only: Project Settings -> Cloud Messaging -> upload your APNs key.
4. Project Settings -> Service accounts -> **Generate new private key** (JSON). You need it in step 4 below.

## 3. Agora (calls)
1. console.agora.io -> new project -> **App ID + App Certificate** (enable certificate).
2. Put the App ID in `lib/core/config.dart` (or `--dart-define=AGORA_APP_ID=...`).

## 4. Edge Functions (calls token + push)
```bash
npm i -g supabase
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase secrets set AGORA_APP_ID=xxx AGORA_APP_CERTIFICATE=xxx WEBHOOK_SECRET=some-long-random-string
supabase secrets set FCM_SERVICE_ACCOUNT="$(cat service-account.json)"
supabase functions deploy agora-token
supabase functions deploy send-push --no-verify-jwt
```
Then Supabase Dashboard -> Database -> **Webhooks** -> create two webhooks:
- `push_notifications`: table `notifications`, event **Insert**, type HTTP Request (POST) -> URL
  `https://YOUR_PROJECT_REF.supabase.co/functions/v1/send-push`, add header `x-webhook-secret: <same secret>`.
- `push_calls`: same, but table `calls`.

## 5. Flutter project files
This zip contains `lib/`, `pubspec.yaml`, `assets/`, `supabase/`. Create the native folders:
```bash
flutter create --org com.vibex --project-name vibex .
flutter pub get
```
(Run it inside this folder; it will not overwrite `lib/` or `pubspec.yaml`.)

### Android: `android/app/src/main/AndroidManifest.xml` (inside `<manifest>`, above `<application>`)
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>
<uses-permission android:name="android.permission.BLUETOOTH"/>
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.USE_FULL_SCREEN_INTENT"/>
<uses-permission android:name="android.permission.WAKE_LOCK"/>
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
<uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
<queries>
  <package android:name="com.whatsapp"/>
  <package android:name="com.whatsapp.w4b"/>
  <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>
</queries>
```
### Android: `android/app/build.gradle` (or `.kts`)
- `minSdkVersion 23`
- inside `compileOptions`: `coreLibraryDesugaringEnabled true`
- inside `dependencies`: `coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.4'`
- at the bottom: `apply plugin: 'com.google.gms.google-services'` and add the
  `com.google.gms:google-services` classpath / plugin as Firebase's setup page shows.

### iOS: `ios/Runner/Info.plist`
```xml
<key>NSCameraUsageDescription</key><string>Video calls and photo posts</string>
<key>NSMicrophoneUsageDescription</key><string>Calls and voice notes</string>
<key>NSPhotoLibraryUsageDescription</key><string>Choose photos and videos from your gallery</string>
<key>LSApplicationQueriesSchemes</key><array><string>whatsapp</string></array>
<key>UIBackgroundModes</key><array><string>remote-notification</string><string>voip</string><string>audio</string></array>
```
Enable Push Notifications + Background Modes in Xcode (Signing & Capabilities).

## 6. Run / build
```bash
flutter run --dart-define=SUPABASE_URL=https://xxx.supabase.co \
            --dart-define=SUPABASE_ANON_KEY=xxx --dart-define=AGORA_APP_ID=xxx
flutter build apk --release --dart-define=... (same defines)
```
Use real devices for calls and push (emulators do not ring reliably).

## 7. How premium works
1. User opens **Get Premium**, picks a plan (Students Vibe 299 / Pro 499 / Pro Max 1999) and taps
   **Apply via WhatsApp** -> WhatsApp opens to 01607040609 with profile name, username, user ID, email/phone and plan.
2. You get the payment on WhatsApp, open **Profile -> menu -> Admin panel**, generate a code, send it.
3. User taps **I have a Redeem Code**, enters it -> **Congratulations screen** with profile picture,
   blue tick (gold for Pro Max), plan, expiry and perks. The code is deactivated instantly.
4. Premium perks coded: tick on every post/comment/chat/profile, unlimited daily posts (free = 5/day),
   reels up to 5 min (free = 60 s). Expiry removes the tick (schedule `expire_premiums()` with pg_cron).
5. Test code `1216` (Pro, 30 days) is in `schema.sql`. **Delete it before launch.**

## 8. Known limits (be aware)
- Chat is encrypted in transit and protected by RLS, but not Signal-style end-to-end encrypted.
- `chat-media` bucket is public-read (unguessable URLs). Make it private + signed URLs for stricter privacy.
- Incoming call when the app is fully **terminated** uses the FCM data push + CallKit. On iOS, true VoIP
  (PushKit) is more reliable; see the flutter_callkit_incoming docs if you need that.
- Supabase free plan limits uploads to 50 MB per file.
- Package versions move fast. If `flutter pub get` complains, run `flutter pub upgrade --major-versions`
  and fix any renamed APIs.
