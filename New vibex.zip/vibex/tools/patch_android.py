import pathlib, re

root = pathlib.Path('android')

# 1) permissions + WhatsApp visibility
mf = root / 'app/src/main/AndroidManifest.xml'
s = mf.read_text()
if 'RECORD_AUDIO' not in s:
    block = '''
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.CAMERA"/>
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>
    <uses-permission android:name="android.permission.BLUETOOTH"/>
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.USE_FULL_SCREEN_INTENT"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
    <queries>
        <package android:name="com.whatsapp"/>
        <package android:name="com.whatsapp.w4b"/>
        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>
    </queries>
    '''
    s = s.replace('<application', block + '<application', 1)
    mf.write_text(s)

# 2) gradle: minSdk 23 + core library desugaring (needed by flutter_local_notifications)
for name, kts in (('build.gradle.kts', True), ('build.gradle', False)):
    p = root / 'app' / name
    if not p.exists():
        continue
    g = p.read_text()
    g = re.sub(r'minSdk(Version)?\s*=?\s*flutter\.minSdkVersion',
               'minSdk = 23' if kts else 'minSdkVersion 23', g)
    if 'esugaring' not in g:
        flag = 'isCoreLibraryDesugaringEnabled = true' if kts else 'coreLibraryDesugaringEnabled true'
        g = re.sub(r'(compileOptions\s*\{)', r'\1\n        ' + flag, g, count=1)
        dep = ('coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")' if kts
               else "coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.4'")
        if re.search(r'^dependencies\s*\{', g, re.M):
            g = re.sub(r'^(dependencies\s*\{)', r'\1\n    ' + dep, g, count=1, flags=re.M)
        else:
            g += '\ndependencies {\n    ' + dep + '\n}\n'
    p.write_text(g)
    print('patched', p)
