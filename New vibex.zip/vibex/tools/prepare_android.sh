#!/usr/bin/env bash
# Creates the android/ folder and patches it for VibeX (permissions, minSdk, desugaring).
# Used by GitHub Actions, and you can run it locally too:  bash tools/prepare_android.sh
set -e
rm -rf /tmp/vx_bak && mkdir -p /tmp/vx_bak
cp -r lib /tmp/vx_bak/lib
cp pubspec.yaml /tmp/vx_bak/pubspec.yaml
flutter create --org com.vibex --project-name vibex --platforms=android .
rm -rf lib && cp -r /tmp/vx_bak/lib lib
cp /tmp/vx_bak/pubspec.yaml pubspec.yaml
rm -rf test
python3 tools/patch_android.py
echo "Android project ready."
